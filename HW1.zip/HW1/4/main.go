package main

import (
	"fmt"
	"math/rand"
	"os"
	"os/signal"
	"sync"
	"syscall"
	"time"
)

type myChans struct {
	sig  chan os.Signal
	data chan string
	stop chan interface{}
	term chan interface{}
}

func NewmyChans(poolSize int) *myChans {
	return &myChans{
		sig:  make(chan os.Signal, 1),
		data: make(chan string, poolSize),
		stop: make(chan interface{}),
		term: make(chan interface{}),
	}
}

func main() {
	workerPoolSize := 10
	c := NewmyChans(workerPoolSize)

	// wait for ctrl+c
	signal.Notify(c.sig, syscall.SIGINT)
	go func(c *myChans) {
		for {
			switch <-c.sig {
			case syscall.SIGINT:
				fmt.Printf("Get ^C\n")
				c.stop <- 0
				close(c.stop)
				close(c.sig)
				return
			default:
				fmt.Printf("Unknown signal\n")
			}
		}
	}(c)

	go Wrtochan(c)
	go worksStrt(workerPoolSize, c)
	<-c.term

}

func worksStrt(workerPoolSize int, c *myChans) {
	wg := new(sync.WaitGroup)
	for i := 0; i < workerPoolSize; i++ {
		workerNumber := i
		wg.Add(1)
		go func(dataCh chan string, id int, wg *sync.WaitGroup) {
			defer wg.Done()
			for data := range dataCh {
				fmt.Printf("worker(%d) data: %s\n", id, data)
				time.Sleep(time.Millisecond * 100)
			}

		}(c.data, workerNumber, wg)
	}
	wg.Wait()
	fmt.Println("Finished data read")
	c.term <- 0
}

func Wrtochan(c *myChans) {
	for {
		select {
		case <-c.stop:
			fmt.Println("ctrl+c")
			close(c.data)
			return
		default:
			res := make([]byte, (rand.Intn(256-8) + 8))
			for n := range res {
				res[n] = byte(rand.Intn('2'-'0') + '0')
			}
			c.data <- string(res)
			time.Sleep(time.Millisecond)
		}
	}
}
