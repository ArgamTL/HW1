package main

import (
	"fmt"
	"strings"
)

func main() {

	s := strings.Fields("This is a string one")
	fmt.Println(s)

	length := len(s)
	start := 0
	end := length - 1

	for start < end {
		s[start], s[end] = s[end], s[start]
		start++
		end--
	}
	result := strings.Join(s, " ")
	fmt.Println(result)

}
