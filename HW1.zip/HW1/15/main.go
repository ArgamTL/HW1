package main

import (
	"fmt"
	"math/rand"
)

var justString string

func someFunc() {
	v := createHugeString(1 << 10)
	justString = v[:100]
}

func createHugeString(size int) string {
	str := make([]rune, size)
	for n := range str {
		str[n] = rune(rand.Intn(100) + 9)
	}
	return string(str)
}

func main() {

	someFunc()
	fmt.Println(justString)

	/*
		var justString string

			func someFunc() {
			  v := createHugeString(1 << 10)
			  justString = v[:100]
			}

			func main() {
			  someFunc()
			}
	*/
}
