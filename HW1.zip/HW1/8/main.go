package main

import "fmt"

func main() {

	var number int64 = 100
	var position int64 = 4
	var bit_0_1 int64 = 1
	var result int64

	tmp := uint64(number)
	mask := uint64(1 << position)
	switch bit_0_1 {
	case 0:
		result = int64(tmp &^ mask)
	default:
		result = int64(tmp | mask)
	}

	fmt.Printf("Number = %b", number)
	fmt.Printf("\nResult = %b\n", result)
}
