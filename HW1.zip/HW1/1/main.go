package main

import "fmt"

type Human struct {
	name    string
	surName string
	age     int
}

func (h *Human) Talk() string {
	s := "Hello my name is " + h.name + " " + h.surName + " I am " + fmt.Sprint(h.age) + " old."
	return s
}

type Action struct {
	Human
	act1 string
}

/*
func (a *Action) Talk() string {
	s := "Hello my name is " + a.name + " " + a.surName + " I am " + fmt.Sprint(a.age) + " old."
	return s
}*/

func main() {
	Action := Action{
		act1: "Talking",
		Human: Human{
			name:    "Jhon",
			surName: "Doe",
			age:     30,
		},
	}
	fmt.Println(Action.Talk())
}
