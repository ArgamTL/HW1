package main

import "fmt"

type transport interface {
	navigateToDestination()
}

type client struct{}

func (t *client) startNav(trans transport) {
	fmt.Println("cliant starting the navigation")
	trans.navigateToDestination()
}

type boat struct{}

func (b *boat) navigateToDestination() {
	fmt.Println("boat is navigating to island")
}

type bike struct{}

func (c *bike) driveToDestination() {
	fmt.Println("bike is moving to the destination")
}

// Adapter used by bike

type bikeAdapter struct {
	bikeTransort *bike
}

func (c *bikeAdapter) navigateToDestination() {
	fmt.Println("Adapter modify bike to allow navigation")
	c.bikeTransort.driveToDestination()
}

func main() {
	client := &client{}
	boat := &boat{}

	client.startNav(boat)

	bike := &bike{}
	bikeAdapter := &bikeAdapter{
		bikeTransort: bike,
	}

	client.startNav(bikeAdapter)

}
