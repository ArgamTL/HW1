package main

import "fmt"

func remove(s []int, i int) []int {
	s[i] = s[len(s)-1]
	return s[:len(s)-1]
}

func main() {
	sl := []int{0, 1, 2, 3, 4, 5, 6, 7, 8, 9}

	fmt.Println(remove(sl, 2))
}
