package main

import (
	"fmt"
	"reflect"
)

func main() {
	ch1 := make(chan interface{})
	ch2 := make(chan int)

	var myString string
	var myBool bool
	guess := 5

	fmt.Printf("The type of variable is: %s\n", reflect.TypeOf(ch1))
	fmt.Printf("The type of variable is: %s\n", reflect.TypeOf(ch2))
	fmt.Printf("The type of variable is: %s\n", reflect.TypeOf(myString))
	fmt.Printf("The type of variable is: %s\n", reflect.TypeOf(myBool))
	fmt.Printf("The type of variable is: %s\n", reflect.TypeOf(guess))
}
