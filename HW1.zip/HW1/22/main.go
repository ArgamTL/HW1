package main

import (
	"fmt"
	"math/big"
)

func main() {

	a := big.NewFloat(1073741824) //2^30 1073741824
	b := big.NewFloat(1073745000)
	c := big.NewFloat(0)

	opr := "mult"

	switch opr {
	case "add":
		c = a.Add(a, b)
		fmt.Printf("ADD result: %s \n", c.String())
	case "sub":
		c = a.Sub(a, b)
		fmt.Printf("SUB result: %s \n", c.String())
	case "div":
		c = a.Quo(a, b)

		fmt.Printf("QUO result: %s \n", c.String())
	case "mult":
		c = a.Mul(a, b)
		fmt.Printf("MUL result: %s \n", c.String())
	default:
		fmt.Printf(" 'OPR (add,mult,sub,div)' is not set.")
	}
}
