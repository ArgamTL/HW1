package main

import (
	"fmt"
	"time"
)

func Sleep(x int) {
	<-time.After(time.Second * time.Duration(x))
}

func main() {
	t0 := time.Now()
	Sleep(7)
	t1 := time.Now()
	fmt.Printf("The call to our Sleep 'selfmade func' took %v to run.\n", t1.Sub(t0))
}
