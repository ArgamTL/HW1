package main

import (
	"fmt"
	"sync"
)

func main() {
	nums := []int{2, 4, 6, 8, 10}
	wg := new(sync.WaitGroup)
	mutx := new(sync.Mutex) // worked without also ..
	sum := 0
	for _, number := range nums {
		wg.Add(1)
		//mutx.Lock() //works also..
		go func(number int) {
			defer wg.Done()
			mutx.Lock()         // worked without also ..
			defer mutx.Unlock() // worked without also ..
			sum = sum + (number * number)
		}(number)
	}
	wg.Wait()
	fmt.Printf("The sum squares is: %d", sum)
}
