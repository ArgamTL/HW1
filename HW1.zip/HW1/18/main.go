package main

import (
	"fmt"
	"math/rand"
	"strconv"
	"sync"
)

func main() {
	workerPool := 3
	ch := make(chan int, workerPool)
	wgW := new(sync.WaitGroup)
	wgR := new(sync.WaitGroup)
	wgR.Add(1)
	counter := 0

	go func(counter *int, ch chan int, wg *sync.WaitGroup) {
		for range ch {
			*counter++
			<-ch
		}
		wg.Done()
	}(&counter, ch, wgR)

	for i := 0; i < workerPool; i++ {
		wgW.Add(1)
		go func(id string, ch chan int, wg *sync.WaitGroup) {
			iter := rand.Uint64() % uint64(500)

			for iter > 0 {
				fmt.Printf("Work#%s. Left %d iterations\n", id, iter-1)
				ch <- int(iter)
				iter--
			}
			wg.Done()

		}(strconv.Itoa(i), ch, wgW) // Writing
	}

	wgW.Wait()
	close(ch)
	wgR.Wait()
	fmt.Println("Total iterations: ", counter)

}
