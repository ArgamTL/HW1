package main

import (
	"errors"
	"log"
	"sync"
)

type SafeNumbers struct {
	sync.RWMutex
	numbers map[int]int
}

func (sn *SafeNumbers) WriteNum(num int) {
	sn.Lock()
	defer sn.Unlock()
	sn.numbers[num] = num
}

func (sn *SafeNumbers) ReadNum(num int) (int, error) {
	sn.RLock()
	defer sn.RUnlock()
	if number, ok := sn.numbers[num]; ok {
		return number, nil
	}
	return 0, errors.New("number does not exists")
}

func generateNumbersMap() {
	wg := sync.WaitGroup{}
	// Init our "safe" numbers map struct.
	safeNumbers := &SafeNumbers{
		numbers: map[int]int{},
	}
	// Write.
	for i := 0; i < 100; i++ {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			safeNumbers.WriteNum(i)
		}(i)
	}
	// Read.
	for i := 0; i < 100; i++ {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			number, err := safeNumbers.ReadNum(i)
			if err != nil {
				log.Print(err)
			} else {
				log.Print(number)
			}
		}(i)
	}

	wg.Wait()
}

func main() {
	generateNumbersMap()
}
