package main

import (
	"fmt"
	"time"
)

func main() {
	ch := make(chan string, 6)
	go func() {
		for {
			v, ok := <-ch // we use then the "ok" to jump out
			if !ok {
				fmt.Println("Finish")
				return
			}
			fmt.Println(v)
		}
	}()

	ch <- "hello"
	ch <- "world"
	close(ch) //The first method is to use the channel’s close mechanism.
	//Look point #1 also is an alt way to close ch ...
	time.Sleep(time.Second)
}

/*
// #1. It is a common use to loop through the channel ch until it is closed.
go func() {
	for {
	 for v := range ch {
	  fmt.Println(v)
	 }
	}
   }()
*/
