/*
Here we declared the variable done, of type channel,
to be used as a semaphore to handle the closing of the goroutine.

The closing of a goroutine is not known,
so in Go we use for-loop in combination with the select keyword to listen,
and then call the close method to formally close the channel after the relevant business processing is done.

If the logic of the program is more structured,
you can also not call the close method, because the goroutine will end naturally,
so you don’t need to close it manually.
*/
package main

import (
	"fmt"
	"time"
)

func main() {
	ch := make(chan string, 6)
	done := make(chan struct{})
	go func() {
		for {
			select {
			case ch <- "foo":
			case <-done:
				close(ch)
				return
			}
			time.Sleep(100 * time.Millisecond)
		}
	}()

	go func() {
		time.Sleep(3 * time.Second)
		done <- struct{}{}
	}()

	for i := range ch {
		fmt.Println("Received: ", i)
	}

	fmt.Println("Finish")
}
