/*
Use the context
The third way to do goroutine control and shutdown is to use the Go language context.

This can be used to identify whether the current channel has been closed,
either because it has expired or because it has been cancelled.

So context has its own flexibility for cross-goroutine control,
either by calling context.WithTimeout to control it based on time,
or by actively calling the cancel method itself to close it manually.
*/
package main

import (
	"context"
	"fmt"
	"time"
)

func main() {
	ch := make(chan struct{})
	ctx, cancel := context.WithCancel(context.Background())

	go func(ctx context.Context) {
		for {
			select {
			case <-ctx.Done():
				ch <- struct{}{}
				return
			default:
				fmt.Println("foo...")
			}

			time.Sleep(500 * time.Millisecond)
		}
	}(ctx)

	go func() {
		time.Sleep(3 * time.Second)
		cancel()
	}()

	<-ch
	fmt.Println("Finish")
}
