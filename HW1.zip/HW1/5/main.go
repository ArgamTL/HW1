package main

import (
	"fmt"
	"math/rand"
	"time"
)

func main() {

	duration := 5 // Seconds for limit duration

	msgs := []string{"msg 1 ", "msg 2 ", "msg 3 ", "msg 4 ", "msg 5 ", "msg 6 ", "msg 7 "}

	// msg chanel
	msgCh := make(chan string)
	defer close(msgCh)

	// chanel limit
	limit := time.Second * time.Duration(duration)
	// start time
	start := time.Now()

	go rCh(msgCh)

	// sending data into chanel
	for time.Since(start) < limit {
		msgCh <- msgs[rand.Uint64()%uint64(len(msgs))]
		time.Sleep(time.Second)
	}
}

func rCh(msg chan string) {
	for text := range msg {
		fmt.Printf("Messages: %s\n", text)
	}
}
