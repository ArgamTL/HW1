package main

import "fmt"

func main() {
	temps := []float64{-25.5, -27.4, 13.2, -9.7, 19.0, 15.5, 24.5, 0, 1, 11, -11, -21.0, 32.5, 8}
	group := make(map[int][]float64)
	var interval = 10

	for _, v := range temps {
		k := int((v)/float64(interval)) * interval
		group[k] = append(group[k], v)
	}

	fmt.Println(group)
}
