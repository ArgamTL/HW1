package main

import "fmt"

var m = make(map[string]bool)
var a = []string{}

func main() {

	str := []string{
		"man",
		"man",
		"man",
		"cat",
		"cat",
		"wolf",
		"wolf",
		"tree",
		"tree",
		"cabbage",
		"cabbage",
		"sheep",
		"sheep",
	}

	for _, v := range str {
		add(v)
	}

	fmt.Println(m)
	fmt.Println("##################################################################")
	fmt.Println(a)

}

func add(s string) {
	if m[s] {
		return // Already in the map
	}
	a = append(a, s)
	m[s] = true
}
