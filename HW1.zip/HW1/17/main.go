package main

import (
	"fmt"
	"sort"
)

func binarySearch(needle int, haystack []int) int {

	low := 0
	high := len(haystack) - 1

	for low <= high {
		median := (low + high) / 2

		if haystack[median] < needle {
			low = median + 1
		} else {
			high = median - 1
		}
	}

	if low == len(haystack) || haystack[low] != needle {
		return -1
	}

	return low
}
func main() {
	intSlice := []int{20, 60, 10, 5, 25, 351, 14, 9}
	fmt.Println("Sorted: ", sort.IntsAreSorted(intSlice))
	fmt.Println(intSlice)
	if !sort.IntsAreSorted(intSlice) {
		sort.Ints(intSlice)
	}
	fmt.Println("After sorting: ", intSlice)
	fmt.Println("Found the needle 5 at position: #", binarySearch(5, intSlice))
	fmt.Println("Found the needle 351 at position: #", binarySearch(351, intSlice))
	fmt.Println("Found the needle 25 at position: #", binarySearch(25, intSlice))
	fmt.Println("Found the needle 2 at position: #", binarySearch(2, intSlice))
}
