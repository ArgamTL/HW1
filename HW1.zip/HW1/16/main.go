package main

import (
	"fmt"
	"time"
)

func main() {

	num := []int{5, 6, 7, 2, 1, 0, 8, 9, 23, 12, 76, 72, 60}
	low := 0
	high := len(num) - 1

	startTime := time.Now()
	sorted := quickSort(num, low, high)
	endTime := time.Now()
	diff := endTime.Sub(startTime)

	fmt.Println("Total time taken: ", diff.Seconds(), "seconds")

	fmt.Println(sorted)
}

func partition(arr []int, low, high int) ([]int, int) {
	pivot := arr[high]
	i := low
	for j := low; j < high; j++ {
		if arr[j] < pivot {
			arr[i], arr[j] = arr[j], arr[i]
			i++
		}
	}
	arr[i], arr[high] = arr[high], arr[i]
	return arr, i
}

func quickSort(arr []int, low, high int) []int {
	if low < high {
		var p int
		arr, p = partition(arr, low, high)
		arr = quickSort(arr, low, p-1)
		arr = quickSort(arr, p+1, high)
	}
	return arr
}
