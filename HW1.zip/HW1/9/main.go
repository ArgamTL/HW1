package main

import (
	"fmt"
	"sync"
)

func main() {
	myNumbers := make([]int, 500)
	for i := range myNumbers {
		myNumbers[i] = i
	}

	chInp := make(chan int)
	chOtp := make(chan int)

	wg := new(sync.WaitGroup)
	wg.Add(len(myNumbers))

	go wToSrc(myNumbers, chInp)
	go multx2(chInp, chOtp)
	go rFromOtpt(chOtp, wg)

	wg.Wait()
}

func wToSrc(data []int, chin chan int) {
	defer close(chin)
	for _, elem := range data {
		chin <- elem
	}
}

func rFromOtpt(chotp chan int, wg *sync.WaitGroup) {
	for elem := range chotp {
		fmt.Println(elem)
		wg.Done()
	}
}

func multx2(chin chan int, chot chan int) {
	defer close(chot)
	for elem := range chin {
		chot <- elem * 2
	}
}
