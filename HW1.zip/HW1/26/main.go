package main

import "fmt"

func unique(arr string) bool {
	m := make(map[rune]bool)
	for _, i := range arr {
		_, ok := m[i]
		if ok {
			return false
		}

		m[i] = true
	}

	return true
}

func main() {
	str1 := "abcdef-abcdef"
	str2 := "abcdef"

	fmt.Println(str1+" - ", unique(str1))

	fmt.Println(str2+" - ", unique(str2))

}
