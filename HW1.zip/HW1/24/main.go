package main

import "fmt"

type Point struct {
	x float64
	y float64
}

func newPoint(x, y float64) *Point {

	p := new(Point)
	p.x = x
	p.y = y
	return p

}

func main() {

	pxy := newPoint(30, 29.5)

	fmt.Println(pxy.x - pxy.y)

}
